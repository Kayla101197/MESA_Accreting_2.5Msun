This MESA folder is provided to serve as a general example of how a 2.5 solar mass model of initial solar metallicity would be evolved through the post-AGB phase while experiencing time-varying accretion from a circumbinary disk. This folder contains a number of modifications made by Kayla Martin for this work, as described in the supplied modifications_summary.txt document. 

To use this work directory, you will need to also download and install mesa-r22.11.1 (or any other compatible versions) from this link: https://docs.mesastar.org/en/release-r22.11.1/installation.html

Make sure to apply any alterations to files contained in mesa-r22.11.1 (as described in the modifications_summary.txt document) before moving ahead (or else your code will not compile and run!). For use in modelling other systems, please make as many copies of this work directory as you like, naming them according to your task. 

It is a good idea to keep your work directories outside of the main MESA code directory (e.g., mesa-r22.11.1) so that you do not have to re-install MESA every time you make changes to a model. Your directory tree should look something like the following:
                                 
                                                          MyMESA_dir
                                                              |
                                                              |
                                                             / \
                                                            /   \
                          ----------------------------------     ----------------
                          |            |            |                           |    
                    MESA_model1   MESA_model2   MESA_model3               mesa-r22.11.1
                          |                                                     |
                         _|_                                                  __|__
                        / | \                                                /  |  \
                       /  |  \                                              /   |   \  
  inlist_project, pgstar src mk, rn, re, ...                       star_data   star  chem, turb, eos, ...