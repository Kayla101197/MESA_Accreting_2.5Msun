This MESA folder is provided to serve as a general example of how a 2.5 solar mass model of initial solar metallicity would be evolved through the post-AGB phase while experiencing time-varying accretion from a circumbinary disk. This folder contains a number of modifications made by Kayla Martin for this work, as described in the supplied modifications_summary.txt document. 

To use this work directory, you will need to also download and install MESA version r22.11.1 or later. See https://docs.mesastar.org/en/latest/installation.html

Make sure to apply any alterations to files contained in the main MESA directory (e.g., mesa-rXX.XX.X) as described in the modifications_summary.txt document before moving ahead, to ensure your code compiles and runs correctly. 

It is important to store your working model directories outside of the main MESA directory, so that you do not have to re-install MESA every time you make changes to a model. Your directory tree should look something like the following:
                                 
                                                          MyMESA_dir
                                                              |
                                                              |
                                                             / \
                                                            /   \
                          ----------------------------------     ----------------
                          |            |            |                           |    
                    MESA_model1   MESA_model2   MESA_model3               mesa-rXX.XX.X
                          |                                                     |
                         _|_                                                  __|__
                        / | \                                                /  |  \
                       /  |  \                                              /   |   \  
  inlist_project, pgstar src mk, rn, re, ...                       star_data   star  chem, turb, eos, ...



ENJOY!